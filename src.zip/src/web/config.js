const config = {
  apiUrl: '/api_goki_kanayama'
};

export default config;